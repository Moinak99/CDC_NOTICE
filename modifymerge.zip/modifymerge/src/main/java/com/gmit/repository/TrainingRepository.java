package com.gmit.repository;

import org.springframework.data.repository.CrudRepository;

import com.gmit.model.TrainingModel;

public interface TrainingRepository extends CrudRepository<TrainingModel, Integer> {

}
