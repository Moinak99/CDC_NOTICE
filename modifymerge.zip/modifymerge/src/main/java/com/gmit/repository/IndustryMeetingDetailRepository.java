package com.gmit.repository;

import org.springframework.data.repository.CrudRepository;

import com.gmit.model.IndustryMeetingDetailModel;



public interface IndustryMeetingDetailRepository extends CrudRepository<IndustryMeetingDetailModel, Integer> {

}
